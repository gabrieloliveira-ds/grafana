import requests
import sys
from rich import print as rprint
from rich.console import Console

console = Console()


class Grafana:
    def __init__(
        self,
        Client: str,
        ConnInfo: dict,
        ClusterInfo: list,
        Contactpoint: dict,
        Alerts: dict
    ) -> None:
        self.Client = Client
        self.login = ConnInfo["login"]
        self.password = ConnInfo["password"]
        self.ip = ConnInfo["ip"]

        self.alertconf = Alerts
        self.folders = list(Contactpoint.keys())
        self.clusters = ClusterInfo
        self.contactpoints = Contactpoint
        self.notificationpolices = list(Contactpoint.keys())

        self.base_url = f"http://{self.login}:{self.password}@{self.ip}:3000"
        self.test_connection()
        self.verify_version()
        self.alert._get()

    class Alert:
        def __init__(self, base_url) -> None:
            self.base_url = base_url
            self.url = f"{base_url}/api/v1/provisioning/alert-rules"

        def _template(self, config: dict) -> dict:
            name = config["name"]
            folder = config['folder']
            cluster = config["cluster"]
            database = config["database"]
            sumarry = config["sumarry"]
            description = config["description"]
            sql = config["sql"]
            conditions = config["conditions"]

            nome_geral = f"{name}_{cluster}{database}"
            if len(nome_geral) >= 40:
                nome_geral = nome_geral[:30] + nome_geral[-8:]

            query = [
                {
                    "refId": "A",
                    "queryType": "",
                    "relativeTimeRange": {"from": 600, "to": 0},
                    "datasourceUid": "0",
                    "model": {
                        "format": "time_series",
                        "group": [],
                        "hide": False,
                        "intervalMs": 1000,
                        "maxDataPoints": 43200,
                        "metricColumn": "none",
                        "rawQuery": True,
                        "rawSql": sql,
                        "refId": "A",
                        "select": [[{"params": ["value"], "type": "column"}]],
                        "timeColumn": "time",
                        "where": [
                            {"name": "$__timeFilter", "params": [], "type": "macro"}
                        ],
                    },
                },
                {
                    "refId": "B",
                    "datasourceUid": "-100",
                    "queryType": "",
                    "model": {
                        "refId": "B",
                        "type": "classic_conditions",
                        "datasource": {"uid": "-100", "type": "__expr__"},
                        "conditions": [conditions],
                        "hide": False,
                    },
                },
            ]
            config = {
                "uid": nome_geral.replace("-", "").replace('"', ""),
                "orgID": 1,
                "folderUID": f"folder_{folder}",
                "ruleGroup": name,
                "title": nome_geral,
                "condition": "B",
                "ExecErrState": "Alerting",
                "NoDataState": "Alerting",
                "Annotations": {
                    "summary": sumarry,
                    "description": description,
                },
                "Labels": {"type": folder},
                "data": query,
                "for": 0,
            }
            if len(config["title"]) >= 40:
                config["title"] = config["title"][:30] + config["title"][-8:]

            return config

        def _create(self, setting: dict) -> int:
            request = {
                "url": self.url,
                "headers": {"Content-Type": "application/json"},
                "json": setting,
                "timeout": 5,
            }
            response = requests.post(**request)
            return response.status_code

        def _get(self) -> int:
            request = {
                "url": self.base_url + '/api/alerts',
                "headers": {"Content-Type": "application/json"},
                "timeout": 5,
            }
            response = requests.get(**request)
            rprint(response.status_code)
            rprint(response.json())
            return response.status_code

        def _update(self, setting: dict) -> int:
            request = {
                "url": f"{self.url}/{setting['uid']}",
                "headers": {"Content-Type": "application/json"},
                "json": setting,
                "timeout": 5,
            }
            response = requests.put(**request)
            return response.status_code

        def _delete(self, uid: dict) -> int:
            request = {
                "url": f"{self.url}/{uid}",
                "headers": {"Content-Type": "application/json"},
                "json": {},
                "timeout": 5,
            }
            response = requests.put(**request)
            rprint(f"alert - {response.status_code} | {uid} ")

            if str(response.status_code)[:1] != "2":
                rprint(response.text)

            return response.status_code

        def highcpu(self, cluster: str, trigger: int, time: int, update: bool = False) -> str:
            time_minutes = f"{time//60}m" if time > 60 else '1m'
            sql = f"SELECT $__time(time), (data->>'cpu_utilization')::float8 as cpu FROM psutil_cpu WHERE time > now() - '{time_minutes}'::interval and  dbname = '{cluster}_postgres'   ORDER BY time DESC LIMIT 1 "

            setup = {
                "name": "High_CPU",
                "folder": "Chamados",
                "cluster": cluster,
                "database": "",
                "sumarry": f"CPU avg({time_minutes}) > {trigger}  | fire 1m",
                "description": "CPU is high !",
                "sql": sql,
                "conditions": {
                    "type": "query",
                    "evaluator": {"params": [trigger, 0], "type": "gt"},
                    "operator": {"type": "and"},
                    "query": {"params": ["A"]},
                    "reducer": {"type": "avg", "params": []},
                },
            }

            setting = self._template(setup)
            self._create(setting) if update == True else self._update(setting)
            status = self._create(setting)
            return str(status)

        def archivedown(self, cluster: str, time: int, update: bool = False) -> str:
            time_minutes = f"{time//60}m" if time > 60 else '1m'
            setup = {
                "name": "Archive",
                "folder": "Chamados",
                "cluster": cluster,
                "database": "",
                "sumarry": f"Archive last({time_minutes}) = 'down' | fire 1m",
                "description": "Archive is Down !",
                "sql": f"SELECT  time,  (data->>'is_failing_int')::int FROM archiver WHERE  time > now() - '{time_minutes}'::interval   AND dbname = '{cluster}_postgres' ORDER BY time DESC",
                "conditions": {
                    "type": "query",
                    "evaluator": {"params": [3], "type": "no_value"},
                    "operator": {"type": "and"},
                    "query": {"params": ["A"]},
                    "reducer": {"params": [], "type": "last"},
                },
            }
            setting = self._template(setup)
            self._create(setting) if update == True else self._update(setting)
            status = self._create(setting)
            return str(status)

        def serverdown(self, cluster: str, time: int, update: bool = False) -> str:
            time_minutes = f"{time//60}m" if time > 60 else '1m'
            setup = {
                "name": "Server",
                "folder": "Chamados",
                "cluster": cluster,
                "database": "",
                "sumarry": f"Server last({time_minutes}) = 'down' | fire 2m",
                "description": "Server is Down !",
                "sql": f"SELECT  time,  (data->>'postmaster_uptime_s')::int as uptime_s FROM  wal WHERE  time > now() - '{time_minutes}'::interval and  dbname = '{cluster}_postgres' ORDER BY time DESC LIMIT 1",
                "conditions": {
                    "evaluator": {"params": [1], "type": "no_value"},
                    "operator": {"type": "and"},
                    "query": {"params": ["A"]},
                    "reducer": {"params": [], "type": "last"},
                    "type": "query",
                },
            }

            setting = self._template(setup)
            self._create(setting) if update == True else self._update(setting)
            status = self._create(setting)
            return str(status)

        def maxconnpercent(self, cluster: str, trigger: int, time: int, update: bool = False) -> str:
            time_minutes = f"{time//60}m" if time > 120 else '2m'
            trigger = trigger if trigger > 10 else 10
            setup = {
                "name": "maxConnPercent",
                "folder": "Chamados",
                "cluster": cluster,
                "database": "",
                "sumarry": f"PercentMaxConnections last({time_minutes}) > {trigger}% | fire 2m",
                "description": "maxConnPercent is High !",
                "sql": f"SELECT time, ((data->> 'instance_total')::float)/((data->>'max_connections')::float) as connpercent FROM backends WHERE time > now() - '{time_minutes}'::interval AND dbname = '{cluster}_postgres' ORDER BY time desc",
                "conditions": {
                    "evaluator": {"params": [trigger], "type": "gt"},
                    "operator": {"type": "and"},
                    "query": {"params": ["A"]},
                    "reducer": {"params": [], "type": "last"},
                    "type": "query",
                },
            }

            setting = self._template(setup)
            self._create(setting) if update == True else self._update(setting)
            status = self._create(setting)
            return str(status)

        def create_waitingsession(self, cluster: str, database: str) -> str:
            database = f"_{database}"

            setup = {
                "name": "Waiting",
                "folder": "Alertas",
                "cluster": cluster,
                "database": database,
                "sumarry": "WaitingSession last(1h) > 10 | fire 2m",
                "description": "WaitingSession is High !",
                "sql": f"SELECT  $__timeGroup(time, 4m),  dbname,  max((data->'waiting')::int) as waiting FROM  backends WHERE  time > now() - '20m'::interval and  dbname = '{cluster}{database}' GROUP BY  1, 2 ORDER BY  1, 2",
                "conditions": {
                    "type": "query",
                    "evaluator": {"params": [5], "type": "gt"},
                    "operator": {"type": "and"},
                    "query": {"params": ["A"]},
                    "reducer": {"type": "avg", "params": []},
                },
            }

            setting = self._template(setup)
            status = self._create(setting)
            return str(status)

        def update_archivedown(self, cluster: str, time: int) -> str:
            archive_time = f"{time//60}m" if time > 60 else '1m'
            setup = {
                "name": "Archive",
                "folder": "Chamados",
                "cluster": cluster,
                "database": "",
                "sumarry": f"Archive last({archive_time}) = 'down' | fire 1m",
                "description": "Archive is Down !",
                "sql": f"SELECT  time,  (data->>'is_failing_int')::int FROM archiver WHERE  time > now() - '{archive_time}'::interval   AND dbname = '{cluster}_postgres' ORDER BY time DESC",
                "conditions": {
                    "type": "query",
                    "evaluator": {"params": [3], "type": "no_value"},
                    "operator": {"type": "and"},
                    "query": {"params": ["A"]},
                    "reducer": {"params": [], "type": "last"},
                },
            }
            setting = self._template(setup)
            status = self._update(setting)
            return str(status)

    class ContactPoint:
        def __init__(self, base_url: str) -> None:
            self.url = f"{base_url}/api/v1/provisioning/contact-points"

        def get(self) -> dict:
            request = {
                "url": self.url,
                "headers": {"Content-Type": "application/json"},
                "json": {},
                "timeout": 5,
            }
            response = requests.get(**request)
            return response.json()

        def create(self, name: str, email: list, disableresolved: bool) -> str:
            request = {
                "url": self.url,
                "headers": {"Content-Type": "application/json"},
                "json": {
                    "Name": name,
                    "UID": f"ContactPoint_{name}",
                    "Type": "email",
                    "DisableResolveMessage": disableresolved,
                    "settings": {"addresses": ";".join(email)},
                },
                "timeout": 5,
            }
            response = requests.post(**request)
            return str(response.status_code)

        def update(self, name: str, email: list, disableresolved: bool) -> str:
            request = {
                "url": f"{self.url}/ContactPoint_{name}",
                "headers": {"Content-Type": "application/json"},
                "json": {
                    "Name": name,
                    "UID": f"ContactPoint_{name}",
                    "Type": "email",
                    "DisableResolveMessage": disableresolved,
                    "settings": {"addresses": ";".join(email), "singleEmail": False},
                },
                "timeout": 5,
            }
            response = requests.put(**request)
            return str(response.status_code)

        def delete() -> str:
            ...

    class Folder:
        def __init__(self, base_url) -> None:
            self.url = f"{base_url}/api/folders"

        def get(self) -> None:
            ...

        def create(self, name: str) -> str:
            request = {
                "url": self.url,
                "headers": {"Content-Type": "application/json"},
                "json": {"title": name, "UID": f"folder_{name}"},
                "timeout": 5,
            }
            response = requests.post(**request)
            return str(response.status_code)

        def update(self, name: str, new_name: str) -> str:
            request = {
                "url": f"{self.url}/folder_{name}",
                "headers": {"Content-Type": "application/json"},
                "json": {"title": new_name, "overwrite": True},
                "timeout": 5,
            }
            response = requests.put(**request)
            return str(response.status_code)

        def delete(self, name: str) -> str:
            request = {
                "url": f"{self.url}/folder_{name}",
                "headers": {"Content-Type": "application/json"},
                "json": {},
                "timeout": 5,
            }
            response = requests.delete(**request)
            rprint(f"folder - {response.status_code} | {name} ")
            return str(response.status_code)

    class NotificationPolice:
        def __init__(self, base_url) -> None:
            self.url = f"{base_url}/api/v1/provisioning/policies"

        def get(self) -> dict:
            request = {
                "url": self.url,
                "headers": {"Content-Type": "application/json"},
                "json": {},
                "timeout": 5,
            }
            response = requests.get(**request)
            return response.json()

        def update(self, contactpoint: list) -> str:
            routes = []
            for ct in contactpoint:
                route = {
                    "continue": False,
                    "group_by": [],
                    "object_matchers": [["type", "=", ct]],
                    "routes": [],
                    "mute_time_intervals": [],
                    "receiver": ct,
                }
                routes.append(route)

            conf = {
                "continue": False,
                "group_by": [],
                "object_matchers": [],
                "routes": routes,
                "mute_time_intervals": [],
                "receiver": "grafana-default-email",
            }
            request = {
                "url": self.url,
                "headers": {"Content-Type": "application/json"},
                "json": conf,
                "timeout": 5,
            }
            response = requests.put(**request)
            rprint(f"notificationpolice created  | {contactpoint} ")
            return str(response.status_code)

    class Setting:
        def __init__(self, base_url) -> None:
            self.url = f"{base_url}/api/admin/settings"

        def get(self) -> dict:
            request = {
                "url": self.url,
                "headers": {"Content-Type": "application/json"},
                "json": {},
                "timeout": 5,
            }
            response = requests.get(**request)
            return response.json()

    @property
    def alert(self):
        return self.Alert(self.base_url)

    @property
    def contactPoint(self):
        return self.ContactPoint(self.base_url)

    @property
    def folder(self):
        return self.Folder(self.base_url)

    @property
    def notificationPolice(self):
        return self.NotificationPolice(self.base_url)

    @property
    def setting(self):
        return self.Setting(self.base_url)

    def run_alerts(self):
        rprint("[yellow]----------------------------------Criandos Alertas[/yellow]")
        for cluster in self.clusters:
            name = cluster["cluster"]
            rprint(name, ":")
            if "HighCpu" in cluster["alerts"]:
                trigger = self.alertconf["HighCpu"]["trigger"]
                time = self.alertconf["HighCpu"]["time"]
                status = self.alert.highcpu(name, trigger, time)
                if status[0] == "2":
                    rprint(f"   Alert [green]Created[/green] | HighCpu ")
                if status[0] == "5":
                    status = self.alert.highcpu(name, trigger, time, True)
                    rprint(
                        "    Alert [bright_blue]Updated[/bright_blue] | HighCPU")

            if "ArchiveDown" in cluster["alerts"]:
                time = self.alertconf["ArchiveDown"]["time"]
                status = self.alert.archivedown(name, time)
                if status[0] == "2":
                    rprint(f"   Alert [green]Created[/green] | ArchiveDown ")
                if status[0] == "5":
                    status = self.alert.archivedown(name, time, True)
                    rprint(
                        "     Alert [bright_blue]Updated[/bright_blue] | ArchiveDown")

            if "ServerDown" in cluster["alerts"]:
                time = self.alertconf["ServerDown"]["time"]
                status = self.alert.serverdown(name, time)
                if status[0] == "2":
                    rprint(f"   Alert [green]Created[/green] | ServerDown ")
                if status[0] == "5":
                    status = self.alert.serverdown(name, time, True)
                    rprint(
                        "    Alert [bright_blue]Updated[/bright_blue] | ServerDown")

            if "MaxConnPercent" in cluster["alerts"]:
                trigger = self.alertconf["MaxConnPercent"]["trigger"]
                time = self.alertconf["MaxConnPercent"]["time"]
                status = self.alert.maxconnpercent(name, trigger, time)
                if status[0] == "2":
                    rprint(f"   Alert [green]Created[/green] | MaxConnPercent ")
                if status[0] == "5":
                    status = self.alert.maxconnpercent(name, trigger, time, True)
                    rprint(
                        "    Alert [bright_blue]Updated[/bright_blue] | MaxConnPercent")

            if "WaitingSession" in cluster["alerts"]:
                for db in cluster["databases"]:
                    ...

    def run_contactpoints(self):
        rprint(
            "[yellow]----------------------------------Criandos ContactPoint[/yellow]")
        cp = self.contactpoints
        cp["grafana-default-email"] = {"email": [], "disableresolved": True}

        for name, value in cp.items():
            names = [item["name"] for item in self.contactPoint.get()]

            if name not in names:
                status = self.contactPoint.create(name, **value)
                if status[0] == "2":
                    print(f"contactpoint created | {name}")
                else:
                    print(f"contactpoint erro - {status} | {name}")
            else:
                status = self.contactPoint.update(name, **value)
                if status[0] == "2":
                    print(f"contactpoint updated | {name}")
                else:
                    print(f"contactpoint erro - {status} | {name}")

    def run_folder(self):
        rprint("[yellow]----------------------------------Criandos pastas[/yellow]")
        for folder in self.folders:
            status = self.folder.create(folder)
            if status[0] == "2":
                rprint(f"folder Created | {folder} ")

            if status[0] == "4":
                self.folder.update(folder, folder)
                rprint(f"folder updated | {folder} ")

    def run_notificationpolice(self):
        rprint(
            "[yellow]----------------------------------Criandos NoticePolice[/yellow]")
        self.notificationPolice.update(self.notificationpolices)

    def run(self):
        
        self.run_folder()
        self.run_alerts()
        self.run_contactpoints()
        self.run_notificationpolice()

    def test_connection(self) -> None:
        try:
            requests.get(url=self.base_url + "/", timeout=3)
        except Exception:
            print("TIMEOUT NO SERVIDOR! ('verifique se o ip esta correto')")
            sys.exit()

    def verify_version(self) -> None:
        def err():
            rprint("[red]Versão do grafana incompatível![/red]")
            rprint("[red]instale a versão 9.0.9\n[/red]")
            rprint("[yellow]apt-get install -y adduser libfontconfig1 musl[/yellow]")
            rprint("[yellow]wget [blue]https://dl.grafana.com/oss/release/grafana_9.0.9_amd64.deb[/blue] [/yellow]")
            rprint("[yellow]dpkg -i grafana_9.0.9_amd64.deb[/yellow]")
            sys.exit()
        try:
            resp = requests.get(url=self.base_url + "/api/admin/usage-report-preview", timeout=2)
            json = resp.json()
            vos = json['os']
            vgrafana = json['version']
            rprint(f'{vgrafana=}\n')
            if vgrafana != '9_0_9':
                err()
            
        except Exception:
            err()
        

