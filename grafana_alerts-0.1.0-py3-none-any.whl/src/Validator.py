import json
from jsonschema import validate, ValidationError


def validator(checkjson: dict) -> bool:

    schema_ConnInfo = {
                "type": "object",
                "properties": {
                    "ip": {"type": "string", "format": "ipv4"},
                    "login": {"type": "string"},
                    "password": {"type": "string"}
                },
                "required": ["ip", "login", "password"]
            }
    
    schema_ClusterInfo = {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "cluster": {"type": "string"},
                        "alerts": {"type": "array", "items": {"type": "string"}}
                    },
                    "required": ["cluster", "alerts"]
                }
            }

    schema_ContactPoint = {
                "type": "object",
                "properties": {
                    "Alertas": {
                        "type": "object",
                        "properties": {
                            "email": {"type": "array", "items": {"type": "string"}},
                            "disableresolved": {"type": "boolean"}
                        }
                    },
                    "Chamados": {
                        "type": "object",
                        "properties": {
                            "email": {"type": "array", "items": {"type": "string"}},
                            "disableresolved": {"type": "boolean"}
                        }
                    }
                },
                "required": ["Alertas", "Chamados"]
            }
    
    schema_Alerts = {
                "type": "object",
                "properties": {
                    "HighCpu": {
                        "type": "object",
                        "properties": {
                            "trigger": {"type": "number"},
                            "time": {"time": "number"}
                        },
                        "required": ["trigger", "time"]
                    },
                    "ServerDown": {
                        "type": "object",
                        "properties": {
                            "time": {"time": "number"}
                        },
                        "required": ["time"]
                    },
                    "ArchiveDown": {
                        "type": "object",
                        "properties": {
                            "time": {"time": "number"}
                        },
                        "required": ["time"]
                    },
                    "MaxConnPercent": {
                        "type": "object",
                        "properties": {
                            "trigger": {"type": "number"},
                            "time": {"time": "number"}
                        },
                        "required": ["trigger", "time"]
                    }
                }
            }

    schema_main = {
        "type": "object",
        "properties": {
            "Client": {"type": "string"},
            "ConnInfo": schema_ConnInfo,
            "ClusterInfo": schema_ClusterInfo,
            "Contactpoint": schema_ContactPoint,
            "Alerts": schema_Alerts
        },
        "required": ["Client", "ConnInfo", "ClusterInfo", "Contactpoint", "Alerts"]
    }
    try:
        validate(instance=checkjson, schema=schema_main)
    except ValidationError:
        raise ValueError()
