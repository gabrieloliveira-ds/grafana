from .Grafana import Grafana
from .Validator import validator
from typer import Context, Exit, Option, Typer
import os
import json
import sys

app = Typer()

__version__ = '0.0.1'

def version(arg):
    if arg:
        print(__version__)
        raise Exit(code=0)

@app.callback(invoke_without_command=True)
def typer_callback(
    ctx: Context,
    version: bool = Option(
        False, '--version', '-v', is_eager=True, is_flag=True, callback=version,help='Show app version'
    )
):
    if ctx.invoked_subcommand:
        return
    print('Use o comando `new` para criar um arquivo de configuração ou o comando `run` para executar o script')

@app.command(help='Cria o arquivo de configuração no diretório atual')
def new():
    config = {
    "Client": "Cliente",
    "ConnInfo": {
        "ip": "192.168.201.104",
        "login": "admin",
        "password": "pgwatch2admin"
    },
    "ClusterInfo": [
        {
            "cluster": "pg_db1",
            "alerts": [
                "HighCpu",
                "ArchiveDown",
                "ServerDown",
                "MaxConnPercent"
            ]
        },
        {
            "cluster": "pg_db2",
            "alerts": [
                "HighCpu",
                "ArchiveDown",
                "ServerDown",
                "MaxConnPercent"
            ]
        }
    ],
    "Contactpoint": {
        "Alertas": {
            "email": [
                "teste.chamados@exemplo.com",
                "client@exemplo.com"
            ],
            "disableresolved": False
        },
        "Chamados": {
            "email": [
                "teste.chamados@exemplo.com",
                "client@exemplo.com"
            ],
            "disableresolved": True
        }
    },
    "Alerts": {
        "HighCpu": {
            "trigger": 50,
            "time": 300
        },
        "ServerDown": {
            "time": 180
        },
        "ArchiveDown": {
            "time": 180
        },
        "MaxConnPercent":
        {
            "trigger": 80,
            "time": 300
        }
    }
}

    with open("config.json", "w") as json_file:
        json.dump(config, json_file, indent=4)

@app.command(help='Realiza o providenciamento do grafana')
def run():
    def err(msg: str):
        print(msg)
        sys.exit()

    config_path = os.path.join(os.getcwd(), "config.json")
    if os.path.exists(config_path):
        with open(config_path, "r") as arquivo:
            config = json.load(arquivo)
    else:
        config_path = os.path.join(os.getcwd(), "Grafana_Alerts", "config.json")
        if os.path.exists(config_path):
            try:
                with open(config_path, "r") as arquivo:
                    config = json.load(arquivo)
            except:
                err("Arquivo config.json esta vazio")
        else:
            err("Arquivo config.json não foi encontrado!")

    validator(config)

    gf = Grafana(**config)
    gf.run()


app()
