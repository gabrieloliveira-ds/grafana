import requests
import os
import json

with open(os.path.join(os.getcwd(), "config.json"), "r") as arquivo:
    # Carregar os dados do arquivo
    config = json.load(arquivo)


base_url = f"http://{config['ConnInfo']['login']}:{config['ConnInfo']['password']}@{config['ConnInfo']['ip']}:3000"


def delete_alert(uid) -> None:
    base_url = "http://admin:pgwatch2admin@192.168.201.104:3000"
    path_url = f"/api/v1/provisioning/alert-rules/{uid}"
    request = {
        "url": base_url + path_url,
        "headers": {"Content-Type": "application/json"},
        "json": {},
        "timeout": 5,
    }

    response = requests.delete(**request)
    print(response.status_code)
    print(response.text)


def delete_contactpoint(uid) -> None:
    base_url = "http://admin:pgwatch2admin@192.168.201.104:3000"
    path_url = f"/api/v1/provisioning/contact-points/{uid}"
    request = {
        "url": base_url + path_url,
        "headers": {"Content-Type": "application/json"},
        "json": {},
        "timeout": 5,
    }

    response = requests.delete(**request)
    print(response.status_code)
    print(response.text)


# lista dos alertas escolhidos. as opções são: 'HighCPU', 'ArchiveDown', 'ServerDown' e 'WaitingSession';

#for cluster in config["ClusterInfo"]:
#    if "HighCpu" in cluster["alerts"]:
#        delete_alert("CpuHigh_" + cluster["cluster"])
#
#    if "ArchiveDown" in cluster["alerts"]:
#        delete_alert("Archive_" + cluster["cluster"])
#
#    if "ServerDown" in cluster["alerts"]:
#        delete_alert("Server_" + cluster["cluster"])
#
#    if "MaxConnPercent" in cluster["alerts"]:
#        delete_alert("maxConnPercent_" + cluster["cluster"])
#
#    if "WaitingSession" in cluster["alerts"]:
#        for db in cluster["database"]:
#            delete_alert("Waiting_" + cluster["cluster"] + "_" + db)


delete_alert("Waiting_pg_db1_bancodedados_grgo_funci")

delete_contactpoint("ContactPoint_Chamados")
delete_contactpoint("ContactPoint_Alertas")
